<?php echo get_templete_part('template_part/header'); ?>

	<section class="content">
	</section>

<?php echo get_templete_part('template_part/footer'); ?>